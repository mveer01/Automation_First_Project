package kar;
public class calculator {
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calculator cal = new calculator();
    cal.ADD(4,5);
    cal.SUB(9, 3);
    
	}

	public int ADD(int a, int b)
	{
		int c= a + b;
		return c;
	}
	public int SUB(int d, int e)
	{
	    int f= d - e;	
	    return f;
	}
	
	
}
